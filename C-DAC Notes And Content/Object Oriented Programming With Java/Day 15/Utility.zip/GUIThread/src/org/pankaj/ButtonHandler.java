package org.pankaj;

import java.awt.Button;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonHandler implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		MainFrame frm = (MainFrame) ((Button)e.getSource()).getParent();
		Object dummy = new Object();
		
		Runnable showRectangle = () ->{
		
			try {
				Graphics grp = frm.getGraphics();
				int xPos = 20;
				int yPos = 50;
				while(frm.runningStatus)
				{
					grp.setColor(Color.black);
					grp.drawRect(xPos, yPos, 60,20);
					Thread.sleep(25);
					grp.setColor(Color.white);
					grp.drawRect(xPos, yPos, 60,20);
					
					if(yPos>=300)
					{
						break;
					}
					
					yPos+=2;
				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		};
		Thread rectThread = new Thread(showRectangle);
		//rectThread.setDaemon(true);
		Runnable showCircle = () ->{
			
			try {
				Graphics grp = frm.getGraphics();
				int xPos = 200;
				int yPos = 580;
				
				rectThread.join(3000);
				
				while(frm.runningStatus)
				{
					grp.setColor(Color.black);
					grp.drawOval(xPos, yPos, 50	,50);
					Thread.sleep(25);
					grp.setColor(Color.white);
					grp.drawOval(xPos, yPos, 50,50);
					
					
					
					yPos-=2;
				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		};
		
		
		rectThread.start();
		
		Thread circleThread = new Thread(showCircle);
		circleThread.start();
		
		
		
		

	}

}
