package org.pankaj;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MainFrame();
	}

}
