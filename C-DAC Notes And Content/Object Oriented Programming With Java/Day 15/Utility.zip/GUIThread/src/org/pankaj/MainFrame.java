package org.pankaj;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainFrame extends Frame 
{
	boolean runningStatus = true;
	public MainFrame() 
	{
		setBounds(0,0,600,600);
		setLayout(null);
		
		Button btnStart = new Button("Start");
		
		btnStart.setBounds(530,50,60,20);
		
		btnStart.addActionListener(new ButtonHandler());
		
		add(btnStart);
		
		addWindowListener(new WindowAdapter()
				{
					@Override
					public void windowClosing(WindowEvent we)
					{
						runningStatus = false;
						dispose();
						//System.exit(0);
					}
				});
		setVisible(true);
	}

}
