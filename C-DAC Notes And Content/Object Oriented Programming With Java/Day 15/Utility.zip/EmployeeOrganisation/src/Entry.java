
public class Entry 
{
	
	public static void display(Object obj)
	{
		if(obj instanceof Manager objManager)
		{
			//Manager objManager = (Manager)obj;
			objManager.getHra();
		}
	}

	public static void main(String[] args) 
	{
		// Cover the concept of Pattern Matching for Switch Case Expression
		
		// Boxing & Unboxing
		
		int value = 1;
		
		// Autoboxing
		
		Integer objNum = 12;
		
		display(objNum);
		
		Integer objNum2 = value;
		
		objNum = 12;
		
		int data = objNum;
		
		value = 11;
		
		System.out.println(objNum);
		

		/*
		 * Employee[] arrEmployee = new Employee[50]; final int ADD_MANAGER = 1; final
		 * int ADD_ENGINEER = 2; final int DISPLAY = 8; int count = 0; int choice = 1;
		 * 
		 * do { System.out.println("Enter the choice"); choice = ConsoleInput.getInt();
		 * if (choice == ADD_MANAGER) { System.out.println("Enter the name"); String
		 * name = ConsoleInput.getString(); System.out.println("Enter the address");
		 * String address = ConsoleInput.getString();
		 * System.out.println("Enter the age"); int age = ConsoleInput.getInt();
		 * System.out.println("Enter the hra"); float hra = ConsoleInput.getFloat();
		 * arrEmployee[count++] = new Manager(name, address, age, true, 1.1f, hra); }
		 * 
		 * else if (choice == ADD_ENGINEER) { System.out.println("Enter the name");
		 * String name = ConsoleInput.getString();
		 * System.out.println("Enter the address"); String address =
		 * ConsoleInput.getString(); System.out.println("Enter the age"); int age =
		 * ConsoleInput.getInt(); System.out.println("Enter the over time"); float
		 * overTime = ConsoleInput.getFloat(); arrEmployee[count++] = new Engineer(name,
		 * address, age, true, 1.1f, overTime); }
		 * 
		 * else if (choice == DISPLAY) { if (count > 0) { for (int iTmp = 0; iTmp <
		 * count; iTmp++) { System.out.println(arrEmployee[iTmp].getName());
		 * System.out.println(arrEmployee[iTmp].getAddress());
		 * System.out.println(arrEmployee[iTmp].getAge()); // RTTI determine the type of
		 * // < 16 instanceof >=16 Pattern matching
		 * 
		 * if (arrEmployee[iTmp] instanceof Manager objManager) { // Manager objManager
		 * = System.out.println(objManager.getHra());
		 * System.out.println("Its a manager"); } else if (arrEmployee[iTmp] instanceof
		 * Engineer objEngineer) {
		 * 
		 * System.out.println(objEngineer.getOverTime());
		 * System.out.println("Its a Engineer"); } else
		 * System.out.println("nothing to print");
		 * 
		 * System.out.println("-----------------------------------------"); } } }
		 * 
		 * } while (choice != 9);
		 */
		/*
		 * arrManager[0] = new Manager(name,address,age,true,1.1f,1.1f);
		 * 
		 * arrManager[0].setName("dsfkjldsf");
		 * System.out.println(arrManager[0].getName());
		 */

		/*
		 * System.out.println(objManager.getName());
		 * System.out.println(objManager.getAddress());
		 * System.out.println(objManager.getAge());
		 */
	}

}
