package org.pankaj;

import java.io.IOException;
import java.sql.SQLException;

public class Program {

	public static void main(String[] args) {
		boolean fileStatus = true;
		boolean dbStatus = false;
		String str = "";

		System.out.println("Main - 1");

		try {
			System.out.println("Try - 2");
			// Nested Try Catch
		
			if (!fileStatus)
				throw new IOException("Unable to open the file");
		
			System.out.println("Try - 3 - File Opened");
			
			try
			{
				System.out.println("Inner TRY *** 1");
				
				if (!dbStatus)
					throw new SQLException("No connection to DB");
				
				System.out.println("Inner TRY *** 2");
			}catch(SQLException io)
			{
				// INform the Support team that an exception of this type has occured
				// Email with Exception details - Java Mail API
				// SMS  API
				// Whatsapop API
				System.out.println("Inner Catch " + io);
				//throw new SQLException("dflkjsadkflj",io);
				throw io;
			}
			finally
			{
				System.out.println("Inner Finally");
			}
			
			System.out.println("Try - 4 - Connected");
		} 
		catch(IOException | SQLException except)
		{
			System.out.println("Catch 6 - "+  except);
			
		}
		catch(Error error)
		{
			
		}
		
		finally
		{
			System.out.println("Finally of Outer Try.........");
		}
		
		System.out.println("Main - 7");
	}
	
	public static void display() throws IOException
	{
		
	}
	
	
	
}
