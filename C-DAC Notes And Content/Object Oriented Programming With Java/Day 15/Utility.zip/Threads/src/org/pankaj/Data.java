package org.pankaj;

public class Data 
{
	int num;
}
