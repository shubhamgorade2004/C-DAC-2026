package org.pankaj;

public class DecrementThread implements Runnable {

	
	Data objData;
	
	
	
	public DecrementThread(Data objData) {
		super();
		this.objData = objData;
	}



	@Override
	public void run()
	{
		try {
			while(true)
			{
				synchronized(objData)
				{
					System.out.println(objData.num--);
					Thread.sleep(50);
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
