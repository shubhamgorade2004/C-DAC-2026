package org.pankaj;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class Program {

	public static void main(String[] args) throws Exception 
	{
		LocalDateTime data = LocalDateTime.now(ZoneId.of("America/New_York"));
		
		System.out.println(data);
		
		
		
		/*
		 * Data objData = new Data();
		 * 
		 * IncrementThread incThread = new IncrementThread(objData);
		 * 
		 * 
		 * 
		 * DecrementThread target =new DecrementThread(objData); Thread decThread = new
		 * Thread(target);
		 * 
		 * 
		 * incThread.start(); decThread.start();
		 */
		  
	

	}
	
	
	
}
