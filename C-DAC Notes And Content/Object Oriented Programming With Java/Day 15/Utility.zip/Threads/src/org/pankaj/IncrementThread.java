package org.pankaj;

public class IncrementThread extends Thread 
{
	Data objData;
	
	public IncrementThread(Data objData) {
		super();
		this.objData = objData;
	}

	@Override
	public void run()
	{
		try {
			while(true)
			{
				synchronized(objData)
				{
					System.out.println(objData.num++);
					Thread.sleep(50);
				}				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
