
public class Date 
{
	private int day;
	
	private int month;
	
	private int year;
	
	private int [] noOfDays = {0,31,28,31,30,31,30,31,31,30,31,30,31};
	
	// Settor / mutator
	
	public Date(int dd, int mm, int yy) //throws DateException
	{
		//setDate(dd,mm,yy);
	}
	
	public void setDate(int dd, int mm, int yy)// throws DateException
	{
		if(yy < 1950 || yy > 3000)
			throw new DateException("Invalid year");
		else
			year = yy;
		
		if(mm < 1 || mm > 12)
			month = 1;
		else
			month = mm;
		
		if(dd < 1 || dd > noOfDays[month])
			throw new DateException("Invalid value of day " + day);
		else 
			day = dd;
		
	}
	
	public void addDays(int daysToAdd)
	{
		int totalDays = day + daysToAdd;
		while(totalDays > noOfDays[month])
		{
			totalDays -= noOfDays[month];
			month++;
			if(month>12)
				year++;
			isLeapYear();
		}
		day = totalDays;
	}
	
	public boolean isLeapYear()
	{
		if(year%4==0)
		{
			noOfDays[2] = 29;
			return true;
		}
		else
		{
			noOfDays[2] = 28;
			return false;
		}
	}
	
	public void addMonths(int monthsToAdd)
	{
		int days=0;
		for(int tmp=0;tmp<monthsToAdd;tmp++)
			days+=noOfDays[month+tmp];
		
		addDays(days);
	}
	
	public void addYears(int yearsToAdd)  // 5
	{
		int months = yearsToAdd * 12;
		addMonths(months);  // 60
	}
	
	
	
	//Gettor / Accessor
	
	public int getDay()
	{
		return day;
	}

	public int getMonth() {
		return month;
	}

	

	public int getYear() {
		return year;
	}

	
	
}
