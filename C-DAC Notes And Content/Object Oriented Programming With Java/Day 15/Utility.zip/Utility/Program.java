
public class Program {

	public static void main(String[] args) {

		
			Date objDate = new Date(29,1,2024);
			
			objDate.setDate(88, 2, 2026);
			
			objDate.addMonths(1);
			
			System.out.println(objDate.getDay() + "/" + objDate.getMonth() +"/" + objDate.getYear());
		

		
		

	}

}
