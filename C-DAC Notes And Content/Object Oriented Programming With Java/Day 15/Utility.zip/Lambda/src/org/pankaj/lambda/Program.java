package org.pankaj.lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Program {

	public static void main(String[] args) {
		ArrayList<String> trainees = new ArrayList<>();

		trainees.add("Kiyan");
		trainees.add("Rahul");
		trainees.add("Kajal");
		trainees.add("Aishwarya");
		trainees.add("Keyur");
		trainees.add("Vivek");		
		
		trainees.stream()
				.filter(str -> str.startsWith("K"))
				.sorted()
				.forEach(System.out::println);
		
		List<String> allNames= trainees.stream()
			.filter(str -> str.startsWith("K"))
			.sorted()
			.collect(Collectors.toList());
		
		System.out.println("//////////////////////////////////////");
		System.out.println(allNames);
		System.out.println("--------------------------------------");
		allNames.forEach(System.out::println);
		
		System.out.println("###############################");
		
		trainees.stream()
			.filter(str -> str.length()>5)
			.map(name -> name.toUpperCase())
			.forEach(System.out::println);
		
		
		

		/*
		 * trainees.sort((first, second) -> first.compareTo(second) > 0 ? 1 :
		 * first.compareTo(second) < 0 ? -1 : 0); // Collections.sort
		 * 
		 * System.out.println(trainees);
		 */

		/*
		 * Predicate<String> allNamesHavingA = str -> str.indexOf('a')!=-1;
		 * 
		 * filter(trainees,allNamesHavingA);
		 * 
		 * //Predicate<String> allNamesHavingL = ;
		 * System.out.println("999999999999999999999999999999"); filter(trainees,str ->
		 * str.indexOf('l')!=-1);
		 */
		/*
		 * Consumer<List<String>> consumer = list -> { Iterator<String> iter =
		 * list.iterator(); while(iter.hasNext()) System.out.println(iter.next()); };
		 * 
		 * consumer.accept(trainees);
		 */

	}

	public static void filter(List<String> list, Predicate<String> condition) {
		for (String data : list)
			if (condition.test(data))
				System.out.println(data);
	}

}
