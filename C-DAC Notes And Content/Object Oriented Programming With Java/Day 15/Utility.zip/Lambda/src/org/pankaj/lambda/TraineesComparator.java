package org.pankaj.lambda;

import java.util.Comparator;

public class TraineesComparator implements Comparator<String> {

	@Override
	public int compare(String first, String second) {
		if(first.compareTo(second) > 0) 
			return -1 ; 
		else if(first.compareTo(second) < 0) 
			return 1; 
		else return 0;
	}

}
