package org.pankaj.files;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Program {
	
	

	public static void main(String[] args) 
	{
		saveObject();
		
		
	}


	private static void loadObject() {
		FileInputStream fileStream = null;
		ObjectInputStream objectStream = null;
		
		try {
			fileStream = new FileInputStream("E:\\cdackharghar\\student.txt");
			objectStream = new ObjectInputStream(fileStream);
			
			Student data = (Student)objectStream.readObject();
			
			System.out.println(data.getName());
			System.out.println(data.getAddress());
			System.out.println(data.getAge());
			System.out.println(data.isGender());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				if(objectStream!=null)
					objectStream.close();
				if(fileStream!=null)
					fileStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	private static void saveObject() {
		Student objStudent = new Student("TestName","Address",18,true);

		// Java >=7
		// Introducing Try with Resources
		try(FileOutputStream fileStream = new FileOutputStream("E:\\cdackharghar\\student.txt");
			ObjectOutputStream objectStream = new ObjectOutputStream(fileStream);
				Student obj = new Student();) 
		{
		
			objectStream.writeObject(objStudent);
			
			System.out.println("Student record saved");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception e)
		{
			
		}
		/*
		 * finally{
		 * if(null)
		 * oS.close
		 * if(fs null)
		 * fs.close
		 * }
		 * 
		 */
	}


	private static void readData() {
		FileInputStream fileStream = null;
		
		DataInputStream dataStream = null;
		
		try {
			fileStream = new FileInputStream("E:\\cdackharghar\\data.txt");
			dataStream = new DataInputStream(fileStream);
			
			while(true)
			{
				String type = dataStream.readUTF();
				float salary = dataStream.readFloat();
				int age = dataStream.readInt();
				boolean gender = dataStream.readBoolean();
				
				System.out.println(type);
				System.out.println(salary);
				System.out.println(age);
				System.out.println(gender);
				System.out.println("*******************************************");
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(EOFException eof)
		{
			System.out.println("File Read successfully");
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				if(dataStream!=null)
					dataStream.close();
				if(fileStream!=null)
					fileStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	private static void writingData() {
		FileOutputStream fileStream = null;
		DataOutputStream dataStream = null;
		
		try {
			fileStream = new FileOutputStream("E:\\cdackharghar\\data.txt",true);
			
			dataStream = new DataOutputStream(fileStream);
			
			dataStream.writeUTF("Manager");
			dataStream.writeFloat(350000.00f);
			dataStream.writeInt(33);
			dataStream.writeBoolean(true);
			
			System.out.println("Data written");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				if(dataStream!=null)
					dataStream.close();
				if(fileStream!=null)
					fileStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	private static void readFromFile(File mainFile) {
		FileInputStream fileStream = null;
		
		try {
			fileStream = new FileInputStream(mainFile);
			
			//byte [] arrInput = new byte[(int)mainFile.length()];
			
			//fileStream.read(arrInput);
			
			byte [] arrInput = fileStream.readAllBytes();
			
			
			System.out.println(new String(arrInput));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				if(fileStream!=null)
					fileStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	private static void writeToFile(File mainFile) {
		FileOutputStream fileStream = null;
		
		try
		{
			 fileStream = new FileOutputStream(mainFile,true);
			
			String data = "Welcome to the world of Files......\n";
			
			fileStream.write(data.getBytes());
			
			System.out.println("File written");
		}
		catch(FileNotFoundException fnfe)
		{
			System.out.println("Invalid file path provided");
		}
		catch(IOException io)
		{
			System.out.println("Error writing to file, check permissions");
		}
		finally
		{
			try 
			{
				if(fileStream!=null)
					fileStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
//	rootDirectory.mkdirs();
//	rootDirectory.delete();


	private static void createFile(File rootDirectory) {
		try {
			if(rootDirectory.exists())
				System.out.println("This file si present");
			else
			{
				System.out.println("File not present, crating a new one");
				rootDirectory.createNewFile();
				System.out.println("File Created");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void directoryAttribute() {
		File rootDirectory = new File("E:\\cdackharghar\\CDAC.txt");

		if (rootDirectory.isFile())
			System.out.println("The path represents a file");
		else
			System.out.println("The path represnets a dircetory");
	}

	private static void getFileList() {
		File rootDirectory = new File("E:\\cdackharghar");

		String[] allFiles = rootDirectory.list();

		// Enhanced For Loop or For Each loop
		for (String file : allFiles) {
			System.out.println(file);
		}
	}

}
