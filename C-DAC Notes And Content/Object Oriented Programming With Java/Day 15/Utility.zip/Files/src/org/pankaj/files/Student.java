package org.pankaj.files;

import java.io.Serializable;

// Marker Interface / Tagging Interface

public class Student implements Serializable, AutoCloseable

//  POJO -> Plain Old Java Objects
						// 	POJI Plain Old Java INterface
{
	String name;
	String address;
	transient int age;
	transient boolean gender;
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	public Student(String name, String address, int age, boolean gender) {
		super();
		this.name = name;
		this.address = address;
		this.age = age;
		this.gender = gender;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Close of student fired....");
	}
}
