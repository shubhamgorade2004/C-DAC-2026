package org.pankaj.files;
// Java 17
public sealed interface Operation permits Test 
{
	void operate();     // Must be overridden by the implementing class
	//Java >=8
	static void display() // cannot be overridden / never inherited
	{
		
	}
	
	default void show() // May or may not be overridden
	{
		showInfo();
	}
	// Private Methods was introudced in Java 9
	private void showInfo()
	{
		System.out.println("This is showInfo");
		
	}
}

non-sealed class  Test implements Operation
{
	@Override
	public void operate()
	{
		
	}
	
	@Override
	public void show()
	{
		
	}
}
