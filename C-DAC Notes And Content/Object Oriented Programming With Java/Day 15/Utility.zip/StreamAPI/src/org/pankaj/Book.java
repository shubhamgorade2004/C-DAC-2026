package org.pankaj;

import java.util.Objects;

public class Book {
	int bookId;
	String bookName;
	String bookAuthor;
	int bookYearPublication;
	int bookTotalQuantity;
	BookGenre bookGenre;

	public Book(int bookId, String bookName, String bookAuthor, BookGenre bookGenre, int bookYearPublication,
			int bookTotalQuantity) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.bookYearPublication = bookYearPublication;
		this.bookTotalQuantity = bookTotalQuantity;
		this.bookGenre = bookGenre;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public int getBookYearPublication() {
		return bookYearPublication;
	}

	public void setBookYearPublication(int bookYearPublication) {
		this.bookYearPublication = bookYearPublication;
	}

	public int getBookTotalQuantity() {
		return bookTotalQuantity;
	}

	public void setBookTotalQuantity(int bookTotalQuantity) {
		this.bookTotalQuantity = bookTotalQuantity;
	}

	public BookGenre getBookGenre() {
		return bookGenre;
	}

	public void setBookGenre(BookGenre bookGenre) {
		this.bookGenre = bookGenre;
	}

	@Override
	public int hashCode() {
		return Objects.hash( Integer.valueOf(bookId));
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return bookId == other.bookId;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookAuthor=" + bookAuthor + "]";
	}
}
