package org.pankaj;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Program {

	public static void main(String[] args) {

		List<Book> bookList = Arrays.asList(				
				new Book(1000,"Core Java","Pankaj",BookGenre.TECHNOLOGY,2026,100),
				new Book(1001,"Harry Potter","Ryling",BookGenre.FICTION,2016,50),
				new Book(1002,"Enterprise Java","Pankaj",BookGenre.TECHNOLOGY,2026,90),
				new Book(1003,".NET","Rahul",BookGenre.MYTHOLOGY,2025,500),
				new Book(1004,"New Enterprise Java","Someone",BookGenre.FICTION,2026,9),
				new Book(1005,"Coerw Java","James",BookGenre.TECHNOLOGY,2026,15)
				);
		
		try(Scanner scanner = new Scanner(System.in))
		{
			System.out.println("Enter the name");
			String name = scanner.next();
			name+=scanner.nextLine();
			
			System.out.println("Year of Publication");
			int year = scanner.nextInt();
			
			System.out.println(name);
			System.out.println(year);
		}
				
		
		
		
		//uniqueBooks(bookList);
		
	//	maxBook(bookList);
		
		//grouping(bookList);
		
		//parititioning(bookList);
		

	}

	private static void parititioning(List<Book> bookList) {
		Map<Boolean, List<Book>> partitionedList =  bookList.stream()
			.collect(Collectors.partitioningBy(book -> book.getBookTotalQuantity()>=100));
		
		List<Book> above100 = partitionedList.get(true);
		List<Book> below100 = partitionedList.get(false);
		
		System.out.println("Books with qty >= 100");
		above100.forEach(System.out::println);
		
		System.out.println("**********************");
		System.out.println("Books with qty < 100");
		below100.forEach(System.out::println);
	}

	private static void grouping(List<Book> bookList) {
		Map<BookGenre,List<Book>> booksByGenre =  bookList.stream()
			.collect(Collectors.groupingBy(Book::getBookGenre));
		
		List<Book> bookTech = booksByGenre.get(BookGenre.TECHNOLOGY);
		List<Book> bookFiction = booksByGenre.get(BookGenre.FICTION);
		List<Book> bookMythology = booksByGenre.get(BookGenre.MYTHOLOGY);
		
		bookTech.forEach(System.out::println);
		System.out.println("**********************************");
		
		bookFiction.forEach(System.out::println);
		System.out.println("**********************************");
		
		bookMythology.forEach(System.out::println);
		System.out.println("**********************************");
	}

	private static void maxBook(List<Book> bookList) {
		Optional<Book> optBook = bookList.stream()
		.max((book1,book2)->book1.getBookTotalQuantity()>book2.getBookTotalQuantity() ? 1 :
			book1.getBookTotalQuantity() < book2.getBookTotalQuantity() ? -1 : 0);
		
		if(optBook.isPresent())
		{
			Book maxBook = optBook.get();
			System.out.println(maxBook);
		}
	}

	private static void uniqueBooks(List<Book> bookList) {
		bookList.stream()
			.distinct()
			.forEach(System.out::println);
	}

	private static void sortedBooks(List<Book> bookList) {
		bookList.stream()
			.sorted((book1,book2) -> book1.getBookYearPublication() > book2.getBookYearPublication() ? 1 : book1.getBookYearPublication() < book2.getBookYearPublication() ? -1 :0 )
			.forEach(System.out::println);
	}

	private static void usingCollectors(List<Book> bookList) {
		List<Book> finalList = bookList.stream()
		.filter(book -> book.getBookGenre()==BookGenre.TECHNOLOGY)
		.collect(Collectors.toList());
		
		finalList.forEach(System.out::println);
		System.out.println("****************************");
		
		Iterator<Book> iter = finalList.iterator();
		while(iter.hasNext())
		{
			Book objBook = iter.next();
			System.out.println(objBook.getBookAuthor());
			System.out.println(objBook.getBookId());
			System.out.println("-----------------------------");
		}
	}

	private static void filterOnAuthor(List<Book> bookList) {
		bookList.stream()
			.filter(book -> book.getBookAuthor().equals("Pankaj"))
			.forEach(System.out::println);
	}

}
