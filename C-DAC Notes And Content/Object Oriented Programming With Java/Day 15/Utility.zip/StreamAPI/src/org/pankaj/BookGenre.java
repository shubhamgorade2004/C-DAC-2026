package org.pankaj;

public enum BookGenre 
{
	TECHNOLOGY,
	FICTION,
	CRIMETHRILLER,
	MYTHOLOGY;
	
}
