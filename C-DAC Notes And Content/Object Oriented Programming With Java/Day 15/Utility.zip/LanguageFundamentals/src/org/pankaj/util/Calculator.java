package org.pankaj.util;

import in.cdac.Base;

import in.cdac.Derived;

public class Calculator //extends Date
{

	public void compute()
	{
		Base objBase = new Derived();
		
		
		
	}
	
	
}
