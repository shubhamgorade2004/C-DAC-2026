package org.pankaj.util;

public record Data(String name, String address, int age, boolean gender) 
{
	@Override
	public String toString()
	{
		return name;
	}
}
