package org.pankaj;

public class Date 
{
	private int iPrivate;
	int iPackage;
	protected int iProtected;
	public int iPublic;
	public static int iStatic;
	
	public static void display()
	{
		System.out.println("display of date");
	}
	
	public static void show()
	{
		System.out.println("display of date");
	}
}
