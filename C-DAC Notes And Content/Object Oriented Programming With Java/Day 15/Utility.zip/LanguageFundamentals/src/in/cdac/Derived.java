package in.cdac;

public non-sealed class Derived extends Base
{
	int num3;
	
	//1.4 -> Annotations => special intsturctions given to the compiler 
	
	public Derived() 
	{
		super(90); // 1st statement in your constructor call
		
		System.out.println("This is the defauylt ctor of Derived");
		
		
	}
	
	public Derived(int tmp)
	{
		super(); // default
		System.out.println("para of derivede");
	}
	
	@Override
	public void display()
	{
		System.out.println("Show of Derived");
		
	}
	
	
	public void show()
	{
		System.out.println("show");
	}
	
}
