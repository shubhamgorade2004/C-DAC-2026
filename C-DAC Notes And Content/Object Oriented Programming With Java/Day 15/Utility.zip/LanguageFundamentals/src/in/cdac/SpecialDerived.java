package in.cdac;

public non-sealed class SpecialDerived extends Base {

}
