package in.cdac;

public class Data<T extends Derived>  // Upper Bounded Wildcard

// public class Data<T super Derived> // Lower Bounded Wildcard
{
	// Class variables
	static int iStatic;
	
	T value;
	
	int num1 ;   //instance variable
	float num2;
	boolean status;
	char key;
	static String str;
	
	public static void display()
	{
		System.out.println("display of DATA");
	}
	
	@Override
	public String toString()
	{
		//return "num1:" + num1 + ",num2:" + num2 +",status:" + status;
		
		StringBuffer buffer = new StringBuffer("num1:");
		buffer.append(num1);
		buffer.append(",num2:");
		buffer.append(num2);
		buffer.append(",status:");
		buffer.append(status);
		
		return buffer.toString();
		
	}
	
	
	// Static Block
	static
	{
		// can only access static variable or static functions from this
		// class
		iStatic = 1;
		System.out.println("Stattic block fired");
	}
	
	
	
	{
		System.out.println("Init Block");
	}
	
	public Data()
	{
		
		System.out.println("Data ctor");
	}

	public static int getiStatic() {
		return iStatic;
	}

	public static void setiStatic(int iStatic) {
		Data.iStatic = iStatic;
	}

	public int getNum1() {
		return num1;
	}

	public void setNum1(int num1) {
		this.num1 = num1;
	}

	public float getNum2() {
		return num2;
	}

	public void setNum2(float num2) {
		this.num2 = num2;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public char getKey() {
		return key;
	}

	public void setKey(char key) {
		this.key = key;
	}

	public static String getStr() {
		return str;
	}

	public static void setStr(String str) {
		Data.str = str;
	}
	
	
	
}
