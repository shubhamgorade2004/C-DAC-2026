package in.cdac;

import org.pankaj.util.Data;


public class Program extends java.lang.Object
{
	public static void main(String[] args) throws NullPointerException 
	{
		
		Data objData = new Data("Test","Mumabi",12,true);
		
		System.out.println(objData.address());
		System.out.println(objData.name());
		System.out.println(objData.age());
		
		
		System.out.println(objData);
		
		

	}
	


}