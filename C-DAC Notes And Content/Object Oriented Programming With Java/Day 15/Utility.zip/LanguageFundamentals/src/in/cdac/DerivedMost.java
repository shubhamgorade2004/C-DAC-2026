package in.cdac;

public class DerivedMost extends Derived {

}
