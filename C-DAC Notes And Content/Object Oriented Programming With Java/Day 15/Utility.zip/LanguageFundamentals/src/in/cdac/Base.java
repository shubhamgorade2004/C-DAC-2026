package in.cdac;


public sealed class Base permits Derived,SpecialDerived
{
	final int num1 = 1;
	int num2;
	
	{
		System.out.println("init block");
	}
	
	static int iStatic = 2;
	
	static
	{
		System.out.println("Static block");
		
	}

	public Base()
	{
		System.out.println("default of base");
	}
	
	public Base(int tmp) {
		System.out.println("para ctor of Base");

	}

	// All functions are virtual in nature
	// no keyword as virtual to define Dynamic Poly.
	public void display() {
		System.out.println("Display of Base");
	}

}
