
public class Program {

	public static void main(String[] args) 
	{
		System.out.println(args[0] + args[1]); //1020
		
		int num1 = 10;   //initialization
		int num2;
		int result;
		
		
		num2 = 20; // assignment
		
		result = num1+ num2;
		
		System.out.println(num1+num2);
		

	}

}
