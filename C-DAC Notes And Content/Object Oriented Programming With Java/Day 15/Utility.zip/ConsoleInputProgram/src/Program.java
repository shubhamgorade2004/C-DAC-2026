
public class Program {

	public static void main(String[] args) throws Exception 
	{
		Data objData[] = new Data[100];   /// RC 1
		
		System.out.println("Allocating 100 objects of Data");
		for(int iTmp=0;iTmp<100;iTmp++)
			objData[iTmp]  = new Data();

		System.out.println("Setting data reference to null");
		for(int iTmp=0;iTmp<100;iTmp++)
			objData[iTmp]  = null;

		System.out.println("Requesting the GC priority to be increased");
		
		System.out.println("Allocating 100 objects of Data");
		for(int iTmp=0;iTmp<100;iTmp++)
			objData[iTmp]  = new Data();

		
		System.gc();
		//Thread.sleep(10000);
		System.out.println("Main terminated");
		
	}
	
	

}
