
public class Data 
{
	int num1 = 4;
	int num2 = 6;
	
	static int count = 100;
	
	@Override
	public void finalize()
	{
		System.out.println("Finalize of Data " + count--);
		
	}
	
}
