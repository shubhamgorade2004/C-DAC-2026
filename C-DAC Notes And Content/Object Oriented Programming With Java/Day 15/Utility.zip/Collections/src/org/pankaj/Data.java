package org.pankaj;

public class Data<E,F> 
{
	E value1;
	
	F value2;
	
	E add()	
	{
		return value1;
	}
}
