package org.pankaj;

public class EmployeeId 
{
	int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "EmployeeId [id=" + id + "]";
	}
	
	public EmployeeId() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeId(int id) {
		super();
		this.id = id;
	}

	
	
	
	
}
