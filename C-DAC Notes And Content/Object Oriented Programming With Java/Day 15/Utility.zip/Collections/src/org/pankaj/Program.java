package org.pankaj;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class Program {

	public static void main(String[] args) 
	{
		List<String> names = 
		
		
		
		

		/*
		 * // Single Dim int[] sd = new int[10]; int[] sd1 = { 1, 2, 3, 4, 5 }; // new
		 * int[]{1,2,3,4,5};
		 * 
		 * // Multi Dim // a. Matrix // b.Jagged
		 * 
		 * int[][] matrix = new int[5][10]; // matrix[0-4][0-9] = 9;
		 * 
		 * int[][] jagged = new int[5][]; jagged[0] = new int[3]; jagged[1] = new
		 * int[10]; jagged[2] = new int[5];
		 * 
		 * jagged[0][0] = 1; jagged[0][2] = 3; jagged[1][9] = 99;
		 * 
		 * System.out.println(jagged[0][0]); System.out.println(jagged[0][2]);
		 * System.out.println(jagged[1][9]);
		 */

		/*
		 * 
		 * 
		 * 
		 * Map<EmployeeId,Employee> map = new TreeMap<>(new EmployeeIdComparator());
		 * 
		 * 
		 * map.put(new EmployeeId(1000), new
		 * Engineer("Tushar","asdf",22,true,1.1f,1.2f));
		 * 
		 * map.put(new EmployeeId(1004), new
		 * Engineer("Zahid","asdf",22,true,1.1f,1.2f));
		 * 
		 * map.put(new EmployeeId(1002), new
		 * Engineer("Pankaj","asdf",22,true,1.1f,1.2f));
		 * 
		 * System.out.println("Get all values in the map");
		 * 
		 * Iterator<Employee> iter = map.values().iterator(); while(iter.hasNext()) {
		 * System.out.println(iter.next()); }
		 * 
		 * System.out.println("Get all Keys in the map");
		 * 
		 * Iterator<EmployeeId> keys = map.keySet().iterator(); while(keys.hasNext()) {
		 * System.out.println(keys.next()); }
		 * 
		 * // Key Value Pair
		 * 
		 * Set<Entry<EmployeeId,Employee>> allEntries = map.entrySet();
		 * Iterator<Entry<EmployeeId,Employee>> iterSet = allEntries.iterator();
		 * while(iterSet.hasNext()) { Entry<EmployeeId,Employee> entry = iterSet.next();
		 * System.out.println("Key : " + entry.getKey()); System.out.println("Value : "
		 * + entry.getValue()); System.out.println("********");
		 * 
		 * }
		 * 
		 * 
		 */
		
		// STREAM API
		
		/*
		 * Stream Pipeline
		 * 
		 * Source -> Intermediate Operations (filter, map, sorted) -> Terminal
		 * Operations (collect, forEach)
		 */
		
		// ParallelStreams
		// Threads and synchronization
		
		
		
		Engineer objE1 = new Engineer("Ravi", "Mumbai", 22, true, 1.1f, 1.1f);
		Engineer objE2 = new Engineer("Rita", "Mumbai", 33, false, 1.1f, 1.1f);
		Engineer objE3 = new Engineer("Ravi", "Mumbai", 18, true, 1.1f, 1.1f);
		Engineer objE4 = new Engineer("Pooja", "Mumbai", 44, false, 1.1f, 1.1f);
		// Engineer objE5 = new Engineer("Pooja", "Mumbai", 41, false, 1.1f, 1.1f);

		Comparator<Employee> naturalOrder = (emp1,emp2) -> emp1.getName().compareTo(emp2.getName());
		Comparator<Employee> reverseOrder = naturalOrder.reversed();
		
		
		TreeSet<Employee> employeeSet = new TreeSet<>(
				
					);

		employeeSet.add(objE1);
		employeeSet.add(objE2);
		employeeSet.add(objE3);
		employeeSet.add(objE4); // employeeSet.add(objE5);

		Iterator<Employee> iter = employeeSet.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());
		}

		/*
		 * List<Integer> list = Arrays.asList(40,98,78,33,21,66,11);
		 * 
		 * Collections.sort(list);
		 * 
		 * 
		 * Iterator<Integer> iter = list.iterator(); while(iter.hasNext())
		 * System.out.println(iter.next());
		 * 
		 * 
		 * System.out.println(list);
		 * 
		 * Collections.reverse(list); System.out.println(list);
		 */

		/*
		 * List<String> list =
		 * Arrays.asList("Orange","Banana","Apple","Kiwi","Dragon Fruit");
		 * 
		 * Collections.sort(list);
		 * 
		 * System.out.println(list);
		 */

	}

	public static void display(Object... data) {
		for (Object obj : data)
			System.out.println(obj);
	}

}
